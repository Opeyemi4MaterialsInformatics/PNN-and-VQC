# Supplemental reviewer analyses

The response draft is in `Physica Scripta response to referees.md`. This folder holds local analyses for the Physica Scripta transfer, PHYSSCR-159868. The submitted notebook and CSV files are in the parent folder. The analysis scripts reuse its generator, PNN matrix ordering, loss and restart procedure. The original Overleaf sources are in the sibling `MLST overleaf ` folder.

Use Python 3.13.18 and the pinned packages in `requirements.txt` to reproduce the supplemental results. Run the following from this folder:

```sh
python -m pip install -r requirements.txt
python reviewer_checks.py
python quantum_kernel_check.py
python vqc_scaling_check.py 2
python vqc_scaling_check.py 4
python hardware_checks.py
python vqc_noise_check.py
python reviewer_figures.py
python referee1_checks.py
python manuscript_schematics.py
```

The classical control script uses the ten submitted seeds and fits the classifiers on 300 signals per seed. It uses the submitted 100-signal holdout and a separate balanced 10,000-signal test set with seed `100_000 + seed`. The VQC encoding check uses the first five seeds and identical split and test-set construction. Its exact-statevector L-BFGS-B training defines a separate protocol from the original finite-shot SPSA. The illustrative noisy simulation uses fitted seed-7 models, a linear coupling map and assumed depolarization and bit-flip probabilities. The noise parameters do not come from device calibration.

Each perturbation realization uses one fixed mesh setting across the test signals. Figure 6 shows those observations, the mean, and linearly interpolated 5th and 95th percentiles. Figure 3 shows paired accuracy differences on the fresh tests.

The Referee 1 script regenerates the three-bin spectral threshold and log-spectrum logistic diagnostics, the fixed 8 dB training/SNR-shift evaluation, and the seed-7 coupler, arm-loss and detector sensitivity checks. The component and readout parameters are assumptions. The two-parameter readout refit uses only the original 300 training signals. The ideal and perturbed results share the same fresh test set.
