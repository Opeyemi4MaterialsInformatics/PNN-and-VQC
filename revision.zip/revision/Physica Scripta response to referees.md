# Response to the referees

**Physica Scripta manuscript PHYSSCR-159868**  
**Hardware-Aware Benchmarking of Classical, Photonic, and Superconducting Quantum Classifiers for Low-Latency Signal Classification**

**Author review draft.** The replies below use the section and figure numbers of the submitted manuscript. The new numerical checks are available in this folder. Proposed manuscript changes are written in the future tense wherever they have yet to be incorporated. Remove this note and update the locations and tense after preparing the revised manuscript.

Dear Editor and Referees,

Thank you for the detailed assessments. The comments identified three issues that materially affect our interpretation: the missing classical controls for the photonic decision function, the sensitivity of the quantum encoding to input scaling, and the distinction between a synthetic classifier benchmark and a measurement of an end-to-end hardware system. We address each issue below.

## Referee 1

Thank you for identifying the physical assumptions and reporting details needed to interpret this benchmark. The photonic component is a numerical demonstration of a four-mode classifier. Its results characterize a specific transfer-matrix model and readout, and the supplemental sensitivity studies below use explicitly assumed parameters.

### Major comments

#### 1. Experimental validation

We have no device measurements for this classifier. We will state explicitly in the abstract and conclusion that the photonic results are from numerical simulations of an idealized MZI mesh and that no physical implementation, optical bandwidth or end-to-end latency was measured. An experimental follow-up could program the classifier onto an existing four-mode mesh and measure the transfer matrix, held-out accuracy and latency including encoding, detection and conversion. We will present this as a possible validation experiment, without making a fabrication or measurement commitment. The quantitative budget in our reply to Referee 3, point 4, distinguishes literature reference points and illustrative assumptions from measurements of this classifier.

#### 2. Feature representation

The original features characterize the spectrum’s location, spread and dominant frequency, together with mean-square amplitude, while keeping the input suitable for the four-mode mesh. We agree that this is a deliberately restricted representation. In particular, the generator scales noise to each clean waveform’s power, and training AUC for the univariate mean-square feature spans 0.469–0.544 across ten seeds. We ran the requested three-bin concentration control and logistic regression on the 129 one-sided log-power bins. The threshold is the midpoint between the smallest tone and largest chirp concentration scores in the training set. Log-spectrum standardization and fitting use the 300 training examples only. At each test SNR we hold the 8 dB training and threshold fixed and test on 10,000 new balanced waveforms per seed.

The original 100-signal test sets averaged 1.000 and 0.996, respectively. The fresh-set mean accuracies across ten seeds were as follows.

| Test SNR (dB) | Three-bin threshold | Log-spectrum logistic |
|---:|---:|---:|
| -10 | 0.5000 | 0.5000 |
| -5 | 0.5000 | 0.5000 |
| 0 | 0.6600 | 0.5355 |
| 5 | 1.0000 | 0.9712 |
| 8 | 1.0000 | 0.9977 |
| 10 | 1.0000 | 0.9949 |
| 15 | 1.0000 | 0.9754 |
| 20 | 1.0000 | 0.9531 |

The peak-bin-only control in our reply to Referee 3, point 3, provides a second measure of how easily spectral concentration separates the classes at 8 dB. These are empirical reference accuracies for the specified generator and feature sets. The 129-bin model has a larger input representation than the hardware-inspired four-input models.

#### 3. Fabrication imperfections, calibration and retraining

The original Gaussian perturbations are residual errors in programmed mixing angle and phase. Each realization uses one setting across all test signals. The model has no separate coupler fabrication, propagation loss, dispersion, thermal or temporal error terms. We added a transfer-matrix check in which each MZI has two nominal 50:50 couplers, an internal differential phase of $2\theta$ and independent internal arm power-loss factors. The zero-error factorization reproduces Eq. (9) numerically. We used 50 paired draws with a 0.03 rad coupler mixing-angle SD and independent 0.1–0.7 dB arm loss. The coupler angle perturbations correspond approximately to three percentage points RMS in the individual power splitting ratio near 50:50. These inputs are illustrative assumptions.

On a fresh 10,000-signal seed-7 test set, the modeled accuracies are as follows (mean ± sample SD across setting draws). The ideal row is deterministic.

| Scenario | Frozen readout | Refit gain and bias |
|---|---:|---:|
| Ideal | 0.8702 ± 0.0000 | 0.8702 ± 0.0000 |
| Couplers only | 0.8667 ± 0.0034 | 0.8670 ± 0.0029 |
| Arm loss only | 0.8511 ± 0.0062 | 0.8717 ± 0.0019 |
| Couplers and arm loss | 0.8493 ± 0.0074 | 0.8685 ± 0.0031 |
| Combined with electronics | 0.8456 ± 0.0125 | 0.8631 ± 0.0047 |

The refit updates the electronic gain and bias on the original 300 training signals, with the mesh settings held fixed. This tests limited readout recalibration. Static coupler and phase offsets may be partially compensated by characterizing the transfer functions and reprogramming or retraining the mesh. Differential loss and reduced interference contrast constrain what fixed gain and bias or unitary reprogramming can recover. Thermal crosstalk and drift would require measured cross-channel response and time-dependent calibration. [Bandyopadhyay et al.](https://doi.org/10.1364/OPTICA.424052) · [Pai et al.](https://pubmed.ncbi.nlm.nih.gov/37104594/)

#### 4. Detector and readout nonidealities

The submitted model uses ideal square-law conversion from field to power and a linear power readout with common gain. The supplemental combined scenario in point 3 applies fixed channel-to-channel responsivity mismatch (5% SD), independent additive read noise (SD 0.005 in normalized intensity units), hard saturation at 0.25 and an 8-bit uniform ADC on that range. It illustrates an electronics operating point with the assumed mesh errors. The hard clip is an approximation to readout saturation. In a physical instrument, mismatch leaves a residual common-mode term in the intensity difference, saturation can compress one side more than the other, and noise and quantization can flip decisions near zero. Matched responsivity calibration, appropriate headroom and differential readout may mitigate these effects. Measured device response, detector shot noise and electronics bandwidth are outside this scenario. [Ferreira de Lima et al.](https://doi.org/10.1109/JSTQE.2019.2931252)

#### 5. Mesh architecture and number of columns

The code implements a four-column, six-block, nearest-neighbour rectangular mesh, with zero-indexed mode pairs in propagation order as follows.

| Column | Coupled modes |
|---|---|
| 1 | (0, 1) and (2, 3) |
| 2 | (1, 2) |
| 3 | (0, 1) and (2, 3) |
| 4 | (1, 2) |

Uncoupled modes pass through the ideal column unchanged. With column matrices $G_1$ through $G_4$, the overall map is $U=G_4G_3G_2G_1$. We will add a four-rail schematic with coherent signed-amplitude encoding before column 1, one detector per output and subtraction of the sum on outputs 0–1 from the sum on outputs 2–3. The alternating layout is consistent with a Clements-style rectangular arrangement. [Clements et al.](https://doi.org/10.1364/OPTICA.3.001460)

#### 6. Operating wavelength and bandwidth

The complex-envelope simulation assumes one coherent carrier with fixed mesh settings and does not specify a physical wavelength or optical bandwidth. A telecom-band implementation could choose a device and carrier near 1550 nm, but that value is illustrative. The splitting ratios, phase shifts and losses may vary with wavelength, so the relevant transfer matrix is $U(\lambda)$ and the resulting accuracy can vary across optical channels at unchanged control settings. A practical bandwidth would require measuring $U(\lambda)$ and evaluating the fixed or recalibrated classifier over the measured range. We will distinguish optical carrier wavelength, usable wavelength span, modulation/readout bandwidth and system decision rate. The synthetic waveform frequencies refer to digitally sampled baseband signals. [Hamerly et al.](https://doi.org/10.1038/s41467-022-34308-3)

#### 7. Multiple comparisons, repeated seeds and zero dispersion

**(i)** Applying Holm correction across the five fixed-split McNemar comparisons with the PNN gives adjusted $p=0.000530$ for the shallow four-qubit VQC, 0.000885 for 4D logistic regression, 0.09375 for the small MLP, 0.90625 for the SVM and 1.000 for the forest. Thus the fixed-split six-percentage-point MLP advantage does not meet the corrected 0.05 threshold. The independently regenerated benchmarks are the relevant comparison for the across-dataset ranking.

**(ii)** The repeated shot seeds sample predictions from fixed trained models on a fixed test set. At 4,096 shots, the mean paired 2-qubit minus shallow 4-qubit difference is 1.8 percentage points, with a conditional 95% Student-$t$ interval of approximately 1.24 to 2.36 points across the ten seeds. That interval does not capture retraining or test-set variation. The perturbation experiment likewise measures a conditional response to modeled errors. At 0.30 rad the mean accuracy loss is 17.3 percentage points, with a conditional 95% interval for the mean loss of 14.7 to 19.9 points. The individual-run distribution is wider, with accuracy as low as 45.0%. We will emphasize these effects and their sampling scope. See Referee 3, points 6 and 7.

**(iii)** All ten runs of the shallow four-qubit VQC at 4,096 shots classified exactly 61 of 100 examples correctly. Accuracy therefore has zero observed SD at the metric’s one-example resolution. This does not imply identical bitstring counts, identical predictions for each example, or zero uncertainty on a fresh test set.

### Minor comments

#### 8. Reporting consistency

The seed-7 shallow VQC uses optimization seed 7 on the primary split and seed 107 in the replication loop, giving 0.61 and 0.62 respectively. The primary 2D logistic-regression accuracy is 0.57. Eq. (7) will state mean-square amplitude, $N^{-1}\sum_n x[n]^2$. The four-dimensional logistic, RBF-SVM, random forest and small MLP in the primary comparison receive the training-fitted, clipped $[0,2\pi]$ inputs. The new matched quadratic controls instead use the same amplitude scaling as the photonic classifier.

#### 9. Mapping to physical phase shifters

In an ideal balanced MZI convention the transmitted and cross-coupled powers are $\cos^2(\Delta/2)$ and $\sin^2(\Delta/2)$, so the model’s mixing angle is $\theta=\Delta/2$. The tested $\theta$ RMS values of 0, 0.01, 0.02, 0.05, 0.10, 0.20 and 0.30 rad therefore correspond to internal differential-phase RMS values of 0, 0.02, 0.04, 0.10, 0.20, 0.40 and 0.60 rad, respectively (approximately 0°, 1.15°, 2.29°, 5.73°, 11.46°, 22.92° and 34.38°). The model’s $\phi$ is a separate phase coordinate. In the supplemental factorization it is the differential phase of each of two port-phase blocks, with rail phases $\pm\phi/2$. Electrical errors and RMS phase per physical actuator depend on the bias scheme and device calibration. The conversion for $\theta$ applies specifically to internal differential phase.

#### 10. Signed amplitude encoding and input power

A physical implementation could split a common coherent carrier into four paths, apply the amplitude magnitudes with calibrated modulators, and apply a relative $\pi$ phase to encode negative components. Positive and negative amplitudes interfere as intended only while the relative channel phases are stable. For the submitted encoder $x_i \in [-0.5,0.5]$, total normalized input power is $\sum_i x_i^2\leq1$. There is no per-sample unit-power normalization. On the 10,000-signal seed-7 test set the median normalized power was 0.221, the 5th–95th percentile range was 0.058–0.427, and the maximum was 0.751. The variation affects detector headroom and SNR. Normalizing each sample would change the relation of the differential power to the fixed bias and would require separate validation.

#### 11. Model sizes and tuning

The size table in our reply to Referee 3, point 1, gives counts for the classical models and the PNN. The PNN fits 12 mesh settings plus gain and bias. The 2-qubit, shallow 4-qubit and alternate 4-qubit VQCs fit 20, 8 and 24 rotation parameters, respectively. The MLP grid spans 49, 97 and 225 fitted parameters with one binary output. We report SVM support-vector counts and forest node counts, which vary with the training set. The original classical search uses inner folds, with the original transforms fitted once on the outer training set. The original PNN and VQC use multi-start selection by training objective. The supplemental classical, fidelity-kernel and exact-statevector VQC searches use fold-local preprocessing. We will identify the tuned and fixed parts of each protocol.

#### 12. Photonic simulation software

The ideal mesh is a custom complex NumPy transfer-matrix implementation. SciPy’s L-BFGS-B routine trains the mesh settings and electronic readout. The submitted manuscript reports NumPy 2.4.4 and SciPy 1.17.0. The supplemental checks were run with NumPy 2.5.2 and SciPy 1.18.0. We will state the implementation and environment in the software description.

#### 13. PCA

Four-PC PCA retains the full four-dimensional standardized feature space. Its role is to provide a common ordering for comparing the first two PCs to all four. The seed-7 explained variance ratios are 56.87%, 24.93%, 14.32% and 3.88%, so the two-PC model retains 81.80% of the standardized training variance. The later scaling and clipping are separate operations.

#### 14. Data leakage and the FFT window

We will use “training-only preprocessing” for the outer evaluation and state precisely where transforms are fitted within inner folds. The FFT is the one-sided real FFT of each 256-sample record with no explicit taper, equivalent to a rectangular record window. Off-bin tones can therefore exhibit spectral leakage, which is distinct from data leakage between training and evaluation.

#### 15. Experimental MZI literature

We will cite fabricated thin-film lithium niobate matrix processors and integrated photonic AI acceleration as demonstrations of the broader technology. We will distinguish their measured tasks and system boundaries from the present simulated classifier. We will also cite the cascaded-MZI conference study in the discussion of optical topology once its publisher record is confirmed. [Zheng et al.](https://doi.org/10.1002/lpor.202400565) · [Ahmed et al.](https://doi.org/10.1038/s41586-025-08854-x) · [Danis et al., DOI supplied by the referee](https://doi.org/10.1117/12.3081175)

#### 16. References for the introductory comparison

We will cite experimental optical processors for core latency and hardware boundaries, the Shastri et al. review for photonic integration and system constraints, and a measured superconducting sampling workload for shot overhead. We will also distinguish predictive baselines, repeated evaluation and physical timing as separate methodological requirements. [Ashtiani et al.](https://www.nature.com/articles/s41586-022-04714-0) · [Bandyopadhyay et al.](https://www.nature.com/articles/s41566-024-01567-z) · [Shastri et al.](https://www.nature.com/articles/s41566-020-00754-y) · [Arute et al.](https://www.nature.com/articles/s41586-019-1666-5)

#### 17. Reference list

We will remove the uncited Akanbi et al. entry and replace the Shastri et al. conference citation with the Nature Photonics review. [Shastri et al.](https://www.nature.com/articles/s41566-020-00754-y)

#### 18. Figure 1

We will replace or redraw the workflow at a fixed aspect ratio, with one LaTeX sizing dimension and labels sized for print. We will show the two-repetition ZZ feature map and four $R_Y/R_Z$ variational repetitions with linear CX for the 2-qubit VQC and the distinct settings of the shallow 4-qubit VQC. The workflow will omit a cross-platform latency ranking. The quantitative context and its assumptions belong with the timing budget in the text.

#### 19. Figure 5

We agree that true-class normalization makes the per-class errors easy to read. To also address Referee 3’s concern about duplicating results in the main text, we propose a supplementary confusion matrix and a short performance summary in the Results. Rows are true classes and columns are predicted classes.

| True class | Predicted tone | Predicted chirp |
|---|---:|---:|
| Tone | 92% (46) | 8% (4) |
| Chirp | 18% (9) | 82% (41) |


## Referee 2

### 1. Hardware measurements, latency, throughput and energy

We agree that the original comparison supports conclusions about predictive accuracy, sensitivity and circuit complexity under stated simulation assumptions. A hardware-level ranking requires comparable measurements that cover the complete decision path. We will give an explicit latency and energy budget beginning with the shared 128 ms acquisition window and digital FFT, features, PCA and scaling. Published photonic classifier latencies and superconducting shot rates provide separate, platform-specific reference points. The budget in our reply to Referee 3, point 4, states their measurement boundaries and shows how the estimates depend on shot count, interfaces and workload.

### 2. Benchmark difficulty and practical generalization

Regeneration measures reproducibility under the specified generator. Its scope is limited to that distribution. In a new control, a single threshold on peak-bin power divided by total one-sided FFT power nearly solves the original task. The SNR stress test also shows that the control trained at 8 dB degrades markedly at low SNR. We will frame the comparison as a benchmark of decision functions on a fixed feature representation, report the conventional spectral control, and describe over-the-air RF validation as an outstanding test of external validity. See Referee 3, point 3.

### 3. Matched quadratic controls

We agree that the real-amplitude MZI classifier with differential intensity detection implements a restricted homogeneous quadratic score plus an intercept. We evaluated traceless homogeneous and general degree-2 logistic regression, QDA, and a 13-parameter MLP using the same four scaled inputs as the PNN. The matched comparisons and derivation below show what the mesh parameterization contributes to the decision function. Any deployment advantage would have to come from the physical implementation.

### 4. Device noise and interpretation of VQC comparisons

The reported finite-shot experiments simulate sampling on ideal circuits. The 2- and 4-qubit configurations also differ in PCA dimension, feature-map repetitions, ansatz and optimization budget. We will describe them as comparisons of complete configurations and remove causal claims about qubit count. Additional exact-statevector experiments tune input range in inner folds and include a fidelity-kernel SVM. A line-coupling transpilation check illustrates the effect of connectivity on circuit counts. Calibrated backend noise and device execution remain outside the verified evidence. See Referee 3, points 2, 4 and 6.

## Referee 3

### 1. PNN decision function, controls and optical extension

For real encoded amplitudes $x$, let $P=\operatorname{diag}(-1,-1,1,1)$. The score is $s(x)=x^{T}Ax+b$, where $A=g\operatorname{Re}(U^{\dagger}PU)$. The imaginary part of the Hermitian form is skew-symmetric on real inputs and contributes zero. The real part is symmetric, and its trace vanishes by unitarity and $\operatorname{tr}(P)=0$. The score is even about the scaling-box midpoint in encoded coordinates and has no linear term there. The 14 optimized settings map into a score space of dimension at most 10, consisting of nine traceless quadratic coefficients and one intercept. A traceless logistic model relaxes the optical constraints without changing this symmetry. A general quadratic adds four linear coefficients and one trace degree of freedom. The class overlap in the PCA projection helps motivate a curved boundary, though the projection alone does not identify the decision geometry in four dimensions.

We fitted the classical controls on the original 300 training signals per seed. Each test protocol is summarized across the ten independently generated training datasets (mean ± sample SD). The matched controls use the four amplitude-scaled PCs, including the same clipping as the PNN. The logistic models use L2 regularization selected by five-fold inner CV. QDA uses covariance regularization of 0.001 and has 29 fitted quantities, counting class means, symmetric covariances and one free prior. All size figures exclude preprocessing. Variable-size models are characterized by their fitted representations.

| Classifier | Fitted classifier size | 100-signal test | 10,000-signal test |
|---|---:|---:|---:|
| PNN | 14 settings, ≤10 score coefficients | 0.882 ± 0.023 | 0.880 ± 0.006 |
| Original logistic | 5 | 0.771 ± 0.066 | 0.789 ± 0.004 |
| Logistic | 5 | 0.771 ± 0.066 | 0.789 ± 0.004 |
| Traceless quadratic | 10 | 0.905 ± 0.022 | 0.903 ± 0.006 |
| MLP 4-2-1 | 13 | 0.870 ± 0.045 | 0.880 ± 0.063 |
| General quadratic | 15 | 0.936 ± 0.030 | 0.933 ± 0.008 |
| QDA | 29 | 0.951 ± 0.031 | 0.944 ± 0.004 |
| RBF-SVM | 41–65 support vectors | 0.942 ± 0.033 | 0.938 ± 0.007 |
| Random forest | 10,148–14,618 tree nodes | 0.919 ± 0.028 | 0.926 ± 0.006 |
| Small MLP | 49, 97, 225 | 0.961 ± 0.027 | 0.961 ± 0.011 |

The general quadratic and QDA exceed the PNN in both test protocols. The traceless relaxation also improves average accuracy. The exact numerical values differ from the referee’s implementation. We report the results of our explicitly specified scaling, regularization, model selection and test generation. A subset of MLP inner fits reached the iteration limit. The table reports the stated fixed optimization budget.

A coherent reference amplitude permits linear cross terms. For $q(x)=x^TAx+d^Tx+b$, use $z=(x,1)$ and the real symmetric block matrix with $A$ in the upper-left block, $d/2$ and its transpose in the off-diagonal blocks and $b$ in the last diagonal entry. If the matrix is $V\Lambda V^T$, a mesh implementing $V^T$ and detector weights given by $\Lambda$ realize $q$. A universal five-mode mesh requires ten two-mode interferometers, compared with six at four modes. Phase coherence, amplitude normalization, signed detector weighting and the associated electronics would be part of that design. The extension shows how one could implement a general quadratic optically. It remains a proposed architecture. [Clements et al.](https://doi.org/10.1364/OPTICA.3.001460)

### 2. VQC scaling, training accuracy and fidelity kernel

We agree that the input range is an encoding hyperparameter. For the single-repetition four-qubit map on the seed-7 training set, the new check gives mean same-class and different-class fidelities of 0.0737 and 0.0681 at range $[0,2\pi]$, and 0.1896 and 0.1594 at $[0,1]$, excluding diagonal entries. The four-qubit exact fidelity-kernel SVM gives mean held-out accuracies of 0.664 and 0.900 at the respective fixed ranges, and 0.916 when the range and $C$ are jointly selected in five inner folds over five outer replications. We refit standardization, PCA, and clipping min–max scaling inside every inner fold. The kernel is evaluated by statevector simulation and is a diagnostic of the encoding. [Shaydulin and Wild](https://doi.org/10.1103/PhysRevA.106.042407) · [Schuld et al.](https://doi.org/10.1103/PhysRevA.103.032430)

We separately tuned the VQC input range using exact parity probabilities, cross-entropy and three L-BFGS-B restarts per fold. Candidate upper endpoints were 0.5, 1, 2, π and 2π. The original feature-map and ansatz topology were retained. This analysis changes the optimizer and eliminates training shot noise in every arm, so comparisons among ranges within this analysis hold those factors fixed. Across the five replications (mean ± sample SD) we obtain the following results.

| Qubits | Input range | Training | 100-signal test | 10,000-signal test |
|---:|---|---:|---:|---:|
| 2 | $[0,2\pi]$ | 0.593 ± 0.047 | 0.570 ± 0.049 | 0.568 ± 0.010 |
| 2 | $[0,1]$ | 0.684 ± 0.029 | 0.676 ± 0.036 | 0.672 ± 0.020 |
| 2 | Inner-CV selected | 0.689 ± 0.022 | 0.672 ± 0.048 | 0.666 ± 0.014 |
| 4 | $[0,2\pi]$ | 0.631 ± 0.027 | 0.634 ± 0.029 | 0.562 ± 0.015 |
| 4 | $[0,1]$ | 0.738 ± 0.027 | 0.714 ± 0.009 | 0.694 ± 0.027 |
| 4 | Inner-CV selected | 0.797 ± 0.025 | 0.778 ± 0.041 | 0.781 ± 0.012 |

There are 20 trainable rotations in the 2-qubit ansatz, eight in the shallow 4-qubit ansatz, and 24 in the alternative 4-qubit ansatz. The rise in accuracy when scaling is tuned supports revising the original interpretation. The fidelity-kernel result confirms that the four-qubit encoding can separate the classes substantially better with an appropriate scale under a different classifier.

For the original finite-shot SPSA workflow, the saved seed-7 selected restarts have training accuracies of 0.610 for 2 qubits and 0.590 for the shallow 4-qubit circuit at 1,024 training shots. The more expressive 4-qubit model reaches 0.743 training accuracy and 0.560 ideal test accuracy on this split. Its training/test gap differs from the low training accuracy of the compact configurations. The comparisons remain specific to the tested feature maps, dimensions, ansätze and optimization procedures. [Huang et al.](https://www.nature.com/articles/s41467-021-22539-9)

### 3. Task difficulty, SNR and RF framing

We evaluated a conventional one-feature control by selecting a threshold on the negative peak-to-total spectral-power ratio with the 300-signal 8 dB training partition in each replication. The criterion was maximum training Youden index, with the threshold placed between adjacent training scores. We then froze the threshold and evaluated 10,000 new balanced waveforms per seed and test SNR. This is a fixed-training-SNR robustness test. Across ten replications, mean accuracy was 0.500, 0.607 and 0.956 at −10, −5 and 0 dB, respectively. All 100,000 fresh signals at the original 8 dB were classified correctly. The threshold also classified every evaluated fresh signal correctly at 5, 10, 15 and 20 dB. Training AUC for the univariate mean-square feature spanned 0.469–0.544. The original four inputs omit this spectral concentration statistic. Mean-square waveform amplitude is a weak discriminator in this generator because the noise scale is tied to each clean waveform’s mean square. The result supports the referee’s interpretation that the current task primarily probes the classifiers’ behavior under the chosen representation.

We will report normalized frequencies in cycles per sample (tones 0.025–0.225, chirp starts 0.015–0.100, chirp endpoints 0.125–0.300) and describe these as synthetic baseband-style waveforms. Claims about fielded RF or radar systems require a separate test on realistic data with additional classes, interference, channel distortion and shift. A chirp-rate overlap sweep and an over-the-air RF benchmark remain open. The latter would test a different task and should use an explicit split and accuracy by SNR. [O’Shea et al.](https://doi.org/10.1109/JSTSP.2018.2797022)

### 4. End-to-end timing, throughput and energy

Under serial processing, a useful budget is $t_{\mathrm{decision}}=N/f_s+t_{\mathrm{FFT/features/PCA}}+t_{\mathrm{classifier}}+t_{\mathrm{output}}$. The record contributes 128 ms at the specified sampling rate, and consecutive nonoverlapping windows arrive at 7.8125 windows/s per stream. Overlapped windows change the decision issue rate to $f_s/H$ for hop $H$, with the initial acquisition requirement still set by the window. Streaming or pipelined implementations require reporting issue rate separately from time to the first decision. The FFT and feature calculation and up to 16 PCA coefficient multiplications are shared before the model-specific scaling. A digital quadratic score needs only 10 distinct quadratic monomials for four inputs, four linear terms and an intercept. The digital classifier time remains hardware- and implementation-dependent.

Published photonic classifiers report 410 ps and under 570 ps for specific chips and workloads. A propagation calculation for an illustrative 1 cm optical path and group index 4 gives about 133 ps. The incremental PNN path also includes coherent input modulation, detection and electronic readout. As an example of conversion sensitivity, assuming a combined 100 ns interface and core budget gives about 128.0001 ms including acquisition, before shared preprocessing and output. A fully serialized 100 ns classifier could accept $10^7$ feature vectors/s in isolation, compared with 7.8 incoming nonoverlapping windows/s in this benchmark. That assumption illustrates the budget and is independent of the published chip measurements. [Bandyopadhyay et al.](https://www.nature.com/articles/s41566-024-01567-z) · [Ashtiani et al.](https://www.nature.com/articles/s41586-022-04714-0)

For a serial VQC path, the incremental time is approximately shot count times the circuit, measurement and reset cycle, plus feature upload and job overhead. Sycamore’s reported one million samples in about 200 s imply 0.2 ms/sample for that historical circuit and control path. At that illustrative rate, 1,024 inference shots would take 204.8 ms and 4,096 would take 819.2 ms, giving total times of 332.8 ms and 947.2 ms including acquisition alone. One serial inference lane could sustain about 4.88 and 1.22 feature vectors/s, respectively, before scheduling overhead. The training shot budget was 1,024 and inference used a sweep, so neither example defines a required operating point. The cited circuit is a different workload and its rate cannot be assigned to the tested VQCs. [Arute et al.](https://www.nature.com/articles/s41586-019-1666-5)

For energy, the comparable quantity at steady rate $R$ is attributable average power divided by $R$, with the same boundaries for acquisition and digital preprocessing, driving and readout, static bias or cooling and reset, and duty cycle. An additional 1 mW of continuously allocated power at 7.8125 decisions/s contributes 128 µJ/decision. That unit sensitivity illustrates why low-rate energy depends on static allocation. No measured system powers are available to rank these platforms. The small four-mode core also leaves little arithmetic over which to amortize conversions. This quantitative budget supports a system-design discussion and does not establish a latency, energy or throughput advantage.

### 5. Scalability

For a dense rectangular universal interferometer, $m(m-1)/2$ two-mode blocks gives 6, 28 and 120 blocks at 4, 8 and 16 modes. The ideal number of sequential mixing layers is of order $m$. In a full-entanglement ZZ feature-map repetition the number of pair interactions is the same 6, 28 and 120, corresponding to 12, 56 and 240 logical CXs in the standard two-CX decomposition before routing and cancellation. An exact statevector uses $2^m$ complex amplitudes. These counts quantify resource growth. Device propagation delay, accumulated residual error, routing and error correction require architecture-specific models. The supplied data establish neither classification accuracy nor robustness at 8 or 16 inputs. We will limit the conclusions to the evaluated dimensions and discuss a shared higher-dimensional feature sweep as a separate experiment. [Clements et al.](https://doi.org/10.1364/OPTICA.3.001460) · [Hamerly et al.](https://doi.org/10.1038/s41467-022-34308-3)

### 6. Hardware noise, perturbation spread and compilation

Each PNN Monte Carlo draw represents one perturbed set of mesh settings shared across the test signals. It describes residual setting uncertainty for a fixed trained model. A static error can be characterized and partially compensated during calibration or in situ training. Dynamic drift would require a time-correlated model and a calibration schedule. The submitted angular-perturbation study treats insertion loss, detector noise, thermal crosstalk and phase quantization as separate mechanisms. The supplemental assumed-parameter loss and readout model is described in Referee 1, points 3 and 4. We will label the angle RMS as a sensitivity parameter and avoid translating it into a process tolerance without platform-specific phase-setting data.

At 0.30 rad the 50 runs have mean 0.697, sample SD 0.092, minimum 0.450, and linearly interpolated 5th percentile 0.533. Using the inverse empirical CDF gives 0.510, consistent with the value in the report. We will state the quantile convention and show realization spread. With the same gate basis and a bidirectional linear coupling map, at optimization level 0 the depth/CX counts are 48/8, 54/33 and 65/36 for the 2-qubit, shallow 4-qubit and alternative 4-qubit circuits. At level 3 with transpiler seed 7 they are 43/8, 46/25 and 57/28. For comparison, unconstrained level-0 results are 48/8, 31/15 and 41/18. In a separate illustrative seed-7 density-matrix check on the routed 2- and shallow 4-qubit circuits, each CX is followed by a two-qubit depolarizing channel. Independent symmetric readout bit flips are included analytically in the parity probability. The stronger assumed setting (0.02 depolarization parameter and 0.03 readout flip probability) reduces the mean absolute distance from the decision threshold from 0.136 to 0.106 for 2 qubits and from 0.115 to 0.065 for 4 qubits. Expected-probability accuracy changes from 0.58 to 0.58 and from 0.61 to 0.60. These figures come from exact-statevector-trained models and isolate margin sensitivity under explicit assumed errors. The generic channel parameters do not come from device calibration, and the simulation omits relaxation, crosstalk, coherent control errors and drift. A device-specific noise result would require a named backend or explicit calibration parameters, a layout, a transpilation configuration and a defined noise model.

### 7. Test-set size and statistical interpretation

At $n=100$ and $p=0.88$, the binomial reference SD is about 0.032. At $p=0.60$ it is about 0.049. These reference values illustrate the scale of test-set variability. The design fixes the number of examples in each class, so the exact conditional variance depends on the two class-specific error rates. The supplemental evaluation uses 10,000 fresh signals per replication with a fixed seed offset and the original training sizes. The mean and across-replication SD on the two test-set sizes are given with the classical controls and VQC results above. The fresh synthetic sets improve precision under the same generator. They cannot establish performance on real RF data. The large-set results for VQCs refer to the new exact-statevector training procedure.

We will report shot-seed variability as conditional on the chosen trained circuit and test set. In particular, the 4,096-shot $p=0.00195$ compares the fixed seed-7 configurations under repeated sampling. The independent datasets are the units for comparing generalization. The photonic analysis will emphasize mean loss and the distribution over residual settings. For example, the mean drop is 0.62 percentage points at 0.01 rad and 17.30 points at 0.30 rad. Monte Carlo significance depends on the number of draws and is secondary to those quantities.

### Minor comments

1. **References to earlier drafts.** We will remove “strengthened,” “earlier logistic-regression-only narrative” and “revised benchmark,” and describe the benchmark directly.
2. **Section 2.4 punctuation.** We will replace the double full stop with a single period.
3. **Chirp notation and duration.** We will call the tone frequency $f_{\mathrm{tone}}$ and the chirp start and end $f_{\mathrm{start}}$ and $f_{\mathrm{end}}$. The chirp denominator is the sample-span $T=(N-1)/f_s=127.5$ ms. The record-length convention for acquisition is $N/f_s=128$ ms. We will correct the punctuation after Eq. (2).
4. **Mean square and citations.** Eq. (7) will use $N^{-1}\sum_n x[n]^2$ and call it mean-square amplitude. We will consolidate the feature motivation and integrate the Jolliffe and Cadima citation into the PCA sentence.
5. **Purpose of PCA.** Four-component PCA retains all four standardized directions and provides a shared ordering for the nested 2D comparison. Subsequent component-wise clipping and scaling can change model geometry. The verified seed-7 variance ratios are 56.87%, 24.93%, 14.32% and 3.88%. The retained 2D variance is 81.80%, leaving 18.20% in the discarded directions.
6. **Inner preprocessing.** We fitted the original transforms once on the outer training partition before inner CV, so validation rows influenced the fold transformations. The original outer tests were untouched. The supplemental pipelines refit every transform inside each inner fold and refit the selected pipeline on the complete outer training partition before evaluation.
7. **Hyperparameter boundaries.** We extended SVM $C$ through $10^4$, MLP $\alpha$ through 1, and searched logistic $C$ from $10^{-2}$ through $10^4$. We retained the legacy (C=1) model for comparison. Where a selected value lies at a grid boundary, the result should be described as best among tested settings.
8. **VQC specification.** The notebook uses `zz_feature_map` with full entanglement and $\alpha=2$, so the single-coordinate phase is $2x_i$ and the pair phase is $2(\pi-x_i)(\pi-x_j)$. The initial variational rotation angles are sampled uniformly on $[-\pi,\pi]$. The VQC uses cross-entropy and `SPSA(maxiter=...)` with other optimizer settings left at the installed defaults. Each restart adds its index to the base seed for the algorithm RNG and sampler. The original 2-qubit and 4-qubit budgets are 600/8 and 1200/12 iterations/restarts, respectively, at 1,024 training shots.
9. **Mesh topology and terminology.** We will give the zero-indexed layers [(0,1),(2,3)], [(1,2)], [(0,1),(2,3)], [(1,2)], cite the rectangular mesh design, and use “interferometric photonic classifier” in the technical description. [Clements et al.](https://doi.org/10.1364/OPTICA.3.001460)
10. **2D logistic regression.** The primary 2D logistic regression accuracy was 0.57, compared with 0.63 for the exact 2-qubit VQC. We will add the baseline value alongside the paired McNemar comparison.
11. **Seed-7 shallow 4-qubit discrepancy.** The primary experiment uses optimization base seed 7. The replication loop uses dataset seed plus 100 for the shallow 4-qubit VQC, so the corresponding base seed is 107. The common seed-7 dataset and split yield 0.61 and 0.62 under these different training seeds. We will label both settings.
12. **Broader quantum reference.** We will support the statement about evaluating potential quantum advantage with the broader benchmark and kernel literature, alongside the application-specific reference where relevant. [Huang et al.](https://www.nature.com/articles/s41467-021-22539-9)
13. **Figure 1.** We will replace the small schematic panels with legible labeled blocks, show the ZZ encoder in both branches and list $R_Y/R_Z$ for the 2-qubit ansatz. The signal/spectrum panels should use actual generator examples, and any projected feature panels should show the observed overlap.
14. **Figure 2.** The replacement plot identifies class 0 as tone and class 1 as chirp and labels the variance explained by each PC. We will use it in the revised figure.
15. **Figure 3.** The replacement plot gives accuracy differences within each replication as PNN minus baseline on the 10,000-signal tests. A zero reference line and a mean marker support interpretation.
16. **Figure 4.** The replacement plot widens the accuracy axis to 0.54–0.67 and labels the test-set size. We will state in the caption that a 0.01 increment is one correctly classified signal. The plotted bars describe shot-seed variability.
17. **Figure 5.** We will move the matrix out of the main Results figure sequence and retain a short performance summary. To address Referee 1’s request, the supplementary matrix will display true-class percentages with the raw counts in each cell.
18. **Figure 6.** The replacement plot is generated directly from the 50 realization accuracies per level and shows individual runs, the mean and the linearly interpolated 5th–95th percentile range. We will use this convention in the caption and supply the figure code.
19. **References.** We will use the Nature Photonics review by Shastri et al. The noise paper authors are Thomas Ferreira de Lima, Alexander N. Tait, Hooman Saeidi, Mitchell A. Nahmias, Hsuan-Tung Peng, Siamak Abbaslou, Bhavin J. Shastri and Paul R. Prucnal. Its DOI is 10.1109/JSTQE.2019.2931252, correcting the mismatch between the printed DOI and its hyperlink. We will remove the uncited Akanbi et al. (2025) entry. [Shastri et al.](https://www.nature.com/articles/s41566-020-00754-y) · [Ferreira de Lima et al.](https://www.queensu.ca/physics/shastrilab/sites/shastwww/files/uploaded_files/publications/journals/55_Ferreira_de_Lima_JSTQE_noise_2020.pdf)
20. **Code and archival release.** The local source contains two byte-identical notebooks. We will identify one canonical notebook, correct the outdated PNN text, and provide a README and pinned environment with reproduction commands. A repository license requires author approval. An archive DOI can be cited once a release has been deposited and the DOI resolves.

Sincerely,  
The authors
